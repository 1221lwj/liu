$(function () {
    $("#select").change(function () {
        if ((($(this).children('option:selected').val()) == 3)){
           $(".box div .change,.start1").removeClass('start1')
        }else {
            $(".box div .change,.start1").addClass('start1')
        }
    })
});