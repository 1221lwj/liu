$(function(){
    $('.btn1').on('click',function(){
        if (($('.btn1').text()) === "编辑") {
            $('.item table input').removeClass("start2");
            $('.item table tr td .data').addClass("start2");
            $('.btn1').text('保存').css({"background-color":"#FF8201","color":"#fff"});
        }else{
            alert('提交表单数据');
            $('.btn1').text('编辑').css({"background-color":"#fff","color":"#000"});
            $('.item table input').addClass("start2");
            $('.item table .data').removeClass("start2");
        }
    });

    $('.btn2').on('click',function(){
        if (($('.btn2').text()) === "编辑") {
            $('.item table .select').removeClass("start");
            $('.item table input').removeClass("start");
            $('.item table .data1').addClass("start");
            $('.btn2').text('保存').css({"background-color":"#FF8201","color":"#fff"});
        }else{
            alert('提交表单数据');
            $('.btn2').text('编辑').css({"background-color":"#fff","color":"#000"});
            $('.item table .select').addClass("start");
            $('.item table input').addClass("start");
            $('.item table .data1').removeClass("start");

        }
    });

    $("#select").change(function () {
        // alert($(this).children('option:selected').val())
        if ((($(this).children('option:selected').val()) == 3)){
            $(".item table .change,.start1").removeClass('start1')
        }else {
            // $(".item table .change,.start1").addClass('start1')
        }
    });
});