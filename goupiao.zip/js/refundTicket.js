$(function () {
    $(".i").on('click', function () {
       $(".order-item-bd").slideToggle();
    });

    $(".tuipiao").on('click', function(){
        $(".ElasticLayer").removeClass('start');
    });

    $(".cancel").on('click', function () {
        $(".ElasticLayer").addClass('start');
    });

    $("#historicalOrder").on('click', function () {
        $(this).addClass('colors');
        $("#noTrip").removeClass('colors');
        $('.ss').addClass('start');
        $('.sss').removeClass('start');
    });

    $("#noTrip").on('click', function () {
        $(this).addClass('colors');
        $("#historicalOrder").removeClass('colors');
        $('.sss').addClass('start');
        $('.ss').removeClass('start');
    });
});

