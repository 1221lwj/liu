//
// $("#add").on('click',function () {
//     $(".item2 .content").addClass('cancel');
//     $(".item2 .add").removeClass('cancel');
// });
// $("#cancel").on('click',function () {
//     $(".item2 .add").addClass('cancel');
//     $(".item2 .content").removeClass('cancel');
// });

//
// $("#submit").on('click',function () {
//
//     var select,name,identificationNumber,sex,mobileNo,email,address,zipCode,passengerType;
//     select = $("#select1").children('option:selected').val();
//     name =  $("[name='name']").val();
//     identificationNumber = $("[name='identificationNumber']").val();
//
//     // var arr = [select,name,identificationNumber];
//     // arr.map(function (index) {
//     //     alert(arr[index]);
//     // });
//
// })