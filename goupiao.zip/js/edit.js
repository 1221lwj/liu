$("#select").change(function () {
    // alert($(this).children('option:selected').val())
    if ((($(this).children('option:selected').val()) == 3)){
        $(".item table .change,.start1").removeClass('start1')
    }else {
        $(".item table .change,.start1").addClass('start1')
    }
});